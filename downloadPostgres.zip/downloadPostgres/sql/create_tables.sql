CREATE TABLE  IF NOT EXISTS file_data ( id SERIAL PRIMARY KEY, 
						filename VARCHAR, 
						type VARCHAR, 
						data bytea);